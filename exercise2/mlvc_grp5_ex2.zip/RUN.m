addpath part1/
addpath part2/
addpath part2/minFunc
% run linear regression
Part1
%% run sparse autoEncoder
train