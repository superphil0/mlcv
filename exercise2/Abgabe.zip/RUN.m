addpath part1/
addpath part2/
% run linear regression
Part1
%% run sparse autoEncoder
train